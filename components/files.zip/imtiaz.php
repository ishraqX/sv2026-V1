<?php
// imtiaz.php — Imtiaz Uddin Chowdhury · ⚙️ Chief Technology Officer
if (file_exists('components/0.nav/navigation.php')) include 'components/0.nav/navigation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imtiaz Uddin Chowdhury — ⚙️ Chief Technology Officer | Sound Vision</title>
    <link rel="stylesheet" href="components/5.team/all-teams.css">
</head>
<body>

<div class="cv-page">

    <div class="cv-bg" aria-hidden="true">
        <div class="cv-bg-glow cv-bg-glow--a"></div>
        <div class="cv-bg-glow cv-bg-glow--b"></div>
        <div class="cv-bg-glow cv-bg-glow--gold"></div>
        <div class="cv-bg-grid"></div>
    </div>

    <div class="cv-content">

        <a href="index.php#team" class="cv-back"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg> Back to Team</a>

        <!-- HERO -->
        <div class="cv-hero">
            <div class="cv-hero-photo-wrap">
                <img src="components/5.team/teamPic/imtiaz.png" alt="Imtiaz Uddin Chowdhury" class="cv-hero-photo" onerror="this.style.display='none'">
                <div class="cv-hero-photo-overlay"></div>
                <div class="cv-hero-photo-ph">👤</div>
            </div>
            <div class="cv-hero-info">
                <span class="cv-role-badge cv-role-badge--teal">⚙️ Chief Technology Officer</span>
                <h1 class="cv-hero-name"><em>Imtiaz</em> Uddin Chowdhury</h1>
                <p class="cv-hero-tagline">Full-stack architect and CTO driving Sound Vision's technology vision — crafting scalable, innovative digital infrastructure with pixel-perfect precision and engineering excellence.</p>
                <div class="cv-hero-stats">
                    <div class="cv-hero-stat"><span class="cv-hero-stat-n">6+</span><span class="cv-hero-stat-l">Years Coding</span></div>
                    <div class="cv-hero-stat"><span class="cv-hero-stat-n">150+</span><span class="cv-hero-stat-l">Apps Built</span></div>
                    <div class="cv-hero-stat"><span class="cv-hero-stat-n">12</span><span class="cv-hero-stat-l">Tech Stacks</span></div>
                    <div class="cv-hero-stat"><span class="cv-hero-stat-n">99%</span><span class="cv-hero-stat-l">Uptime Record</span></div>
                </div>
                <div class="cv-hero-socials">
                    <a href="https://facebook.com" target="_blank" rel="noopener" class="cv-soc-btn" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a>
                    <a href="https://linkedin.com" target="_blank" rel="noopener" class="cv-soc-btn" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-4 0v7h-4V9h4v1.76A4 4 0 0116 8zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg></a>
                    <a href="https://github.com" target="_blank" rel="noopener" class="cv-soc-btn" aria-label="GitHub"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844a9.59 9.59 0 012.504.337c1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg></a>
                    <a href="mailto:imtiaz@soundvision.com.bd" class="cv-soc-btn" aria-label="Email"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 8l10 7 10-7"/></svg></a>
                    <button class="cv-download-btn" onclick="window.print()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.88 18.09A5 5 0 0018 9h-1.26A8 8 0 103 16.29"/></svg> Download CV</button>
                </div>
            </div>
        </div>

        <!-- BODY -->
        <div class="cv-body-grid">

            <aside class="cv-sidebar">

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>Contact</h3></div>
                    <ul class="cv-contact-list">
                        <li class="cv-contact-item">
                            <div class="cv-contact-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 8l10 7 10-7"/></svg></div>
                            <div class="cv-contact-text"><span class="cv-contact-label">Email</span><span class="cv-contact-val"><a href="mailto:imtiaz@soundvision.com.bd">imtiaz@soundvision.com.bd</a></span></div>
                        </li>
                        <li class="cv-contact-item">
                            <div class="cv-contact-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
                            <div class="cv-contact-text"><span class="cv-contact-label">Location</span><span class="cv-contact-val">Dhaka, Bangladesh</span></div>
                        </li>
                        <li class="cv-contact-item">
                            <div class="cv-contact-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg></div>
                            <div class="cv-contact-text"><span class="cv-contact-label">Company</span><span class="cv-contact-val">Sound Vision</span></div>
                        </li>
                    </ul>
                </div>

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>Skills &amp; Expertise</h3></div>
                    <div class="cv-skills-group"><div class="cv-skills-group-label">Frontend</div><div class="cv-chips"><span class="cv-chip">React</span><span class="cv-chip">Vue.js</span><span class="cv-chip">TypeScript</span><span class="cv-chip">Next.js</span></div></div>
                    <div class="cv-skills-group"><div class="cv-skills-group-label">Backend</div><div class="cv-chips"><span class="cv-chip">PHP / Laravel</span><span class="cv-chip">Node.js</span><span class="cv-chip">Python</span><span class="cv-chip">REST APIs</span></div></div>
                    <div class="cv-skills-group"><div class="cv-skills-group-label">Infrastructure</div><div class="cv-chips"><span class="cv-chip">AWS</span><span class="cv-chip">Docker</span><span class="cv-chip">CI/CD</span><span class="cv-chip">MySQL</span><span class="cv-chip">Redis</span></div></div>
                </div>

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>Education</h3></div>
                    <ul class="cv-edu-list">
                        <li class="cv-edu-item">
                            <div class="cv-edu-icon">🎓</div>
                            <div class="cv-edu-body">
                                <div class="cv-edu-degree">BSc — Computer Science & Engineering</div>
                                <div class="cv-edu-inst">BUET</div>
                                <div class="cv-edu-year">2013 – 2017</div>
                            </div>
                        </li>
                        <li class="cv-edu-item">
                            <div class="cv-edu-icon">📜</div>
                            <div class="cv-edu-body">
                                <div class="cv-edu-degree">AWS Certified Solutions Architect</div>
                                <div class="cv-edu-inst">Amazon Web Services</div>
                                <div class="cv-edu-year">2022</div>
                            </div>
                        </li>
                        <li class="cv-edu-item">
                            <div class="cv-edu-icon">📜</div>
                            <div class="cv-edu-body">
                                <div class="cv-edu-degree">Meta React Developer Certificate</div>
                                <div class="cv-edu-inst">Meta / Coursera</div>
                                <div class="cv-edu-year">2021</div>
                            </div>
                        </li>
                    </ul>
                </div>

            </aside>

            <main class="cv-main">

                <div class="cv-stats-row" data-cv-reveal>
                    <div class="cv-stat-card"><div class="cv-stat-card-n">150+</div><div class="cv-stat-card-l">Apps Built</div></div>
                    <div class="cv-stat-card"><div class="cv-stat-card-n">6+</div><div class="cv-stat-card-l">Years Experience</div></div>
                    <div class="cv-stat-card"><div class="cv-stat-card-n">99%</div><div class="cv-stat-card-l">Uptime Record</div></div>
                </div>

                <div class="cv-quote" data-cv-reveal>
                    <span class="cv-quote-mark">"</span>
                    <p class="cv-quote-text">Code is poetry when written with intention. Great software is not just functional — it is elegant, scalable, and built to last.</p>
                </div>

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>About</h3></div>
                    <p class="cv-bio-text">Imtiaz Uddin Chowdhury is the Chief Technology Officer of Sound Vision, responsible for the company's entire technology strategy, architecture decisions, and engineering culture. With expertise spanning front-end, back-end, and cloud infrastructure, he leads the technical team with a focus on quality, scalability, and innovation.</p>
                    <p class="cv-bio-text">He brings a rare blend of deep technical knowledge and strong communication skills — translating complex engineering challenges into clear solutions that serve both business goals and exceptional user experiences. His development philosophy prioritises clean code, rigorous testing, and continuous improvement.</p>
                </div>

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>Experience</h3></div>
                    <div class="cv-timeline">

                        <div class="cv-timeline-item">
                            <div class="cv-tl-dot-col"><div class="cv-tl-dot cv-tl-dot--gold"></div><div class="cv-tl-line"></div></div>
                            <div class="cv-tl-body">
                                <div class="cv-tl-period">2019 — Present</div>
                                <div class="cv-tl-role">Chief Technology Officer</div>
                                <div class="cv-tl-org">Sound Vision · Dhaka</div>
                                <div class="cv-tl-desc">Lead all technology decisions, architect the platform infrastructure, mentor junior developers, and manage delivery of 150+ digital projects with a consistent 99% uptime record.</div>
                            </div>
                        </div>

                        <div class="cv-timeline-item">
                            <div class="cv-tl-dot-col"><div class="cv-tl-dot "></div><div class="cv-tl-line"></div></div>
                            <div class="cv-tl-body">
                                <div class="cv-tl-period">2017 — 2019</div>
                                <div class="cv-tl-role">Senior Full-Stack Developer</div>
                                <div class="cv-tl-org">TechBridge Solutions</div>
                                <div class="cv-tl-desc">Developed enterprise-grade web applications for clients across finance, healthcare, and e-commerce sectors. Led a team of 5 developers through full SDLC.</div>
                            </div>
                        </div>

                        <div class="cv-timeline-item">
                            <div class="cv-tl-dot-col"><div class="cv-tl-dot "></div><div class="cv-tl-line"></div></div>
                            <div class="cv-tl-body">
                                <div class="cv-tl-period">2015 — 2017</div>
                                <div class="cv-tl-role">Junior Web Developer</div>
                                <div class="cv-tl-org">CreativeLab BD</div>
                                <div class="cv-tl-desc">Built responsive websites and internal tools using PHP, JavaScript, and MySQL. Gained foundational experience in agile development practices.</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="cv-card" data-cv-reveal>
                    <div class="cv-card-title"><span class="cv-card-title-line"></span><h3>Key Achievements</h3></div>
                    <div class="cv-highlights">
<div class="cv-highlight-item"><div class="cv-highlight-dot "></div><div class="cv-highlight-text">Architected and deployed Sound Vision's core SaaS platform serving 50+ enterprise clients</div></div>
<div class="cv-highlight-item"><div class="cv-highlight-dot "></div><div class="cv-highlight-text">Reduced average page load time by 65% through advanced caching and CDN optimisation</div></div>
<div class="cv-highlight-item"><div class="cv-highlight-dot "></div><div class="cv-highlight-text">Built automated CI/CD pipelines cutting deployment time from hours to under 8 minutes</div></div>
<div class="cv-highlight-item"><div class="cv-highlight-dot "></div><div class="cv-highlight-text">Mentored 4 junior developers who progressed to senior engineering roles</div></div>
<div class="cv-highlight-item"><div class="cv-highlight-dot "></div><div class="cv-highlight-text">Delivered 150+ production applications with zero critical security incidents</div></div>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <button class="cv-print-fab" onclick="window.print()" aria-label="Print CV"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></button>
</div>

<script>
(function(){
    var els = document.querySelectorAll('[data-cv-reveal]');
    var io  = new IntersectionObserver(function(entries){
        entries.forEach(function(e,i){
            if(!e.isIntersecting) return;
            setTimeout(function(){ e.target.classList.add('cv-in'); }, i * 80);
            io.unobserve(e.target);
        });
    },{ threshold: 0.08 });
    els.forEach(function(el){ io.observe(el); });
})();
</script>

<?php if (file_exists('components/12.footer/footer.php')) include 'components/12.footer/footer.php'; ?>
</body>
</html>
